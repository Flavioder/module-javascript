
    function validateForm() {
        const email = document.getElementById("email").value;
        const phone = document.getElementById("phone").value;
        const password = document.getElementById("password").value;
        const validationMessage = document.getElementById("validationMessage");

        // Validimi i email-it
        const emailtest = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailtest.test(email)) {
            const message = "Email-i nuk eshte ne formatin e duhur.";
            validationMessage.textContent = message;
            validationMessage.style.color = "red"; 
            console.log(message); 
            return;
        }

        // Validimi i telefonit
        const phonetest = /^(068|069)\d{7}$/;
        if (!phonetest.test(phone)) {
            const message = "Numri i telefonit duhet te filloje me 068 ose 069 dhe te permbaje gjithsej 10 numra.";
            validationMessage.textContent = message;
            validationMessage.style.color = "red"; 
            console.log(message); 
            return;
        }

        // Validimi i fjalkalimit
        const passwordtest = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
        if (!passwordtest.test(password)) {
            const message = "Fjalekalimi duhet te kete minimumi 8 karaktere, minimumi 1 shkronje te madhe, 1 te vogel dhe 1 numer.";
            validationMessage.textContent = message;
            validationMessage.style.color = "red"; 
            console.log(message); 
            return;
        }

        const successMessage = "Te gjitha fushat jane valide!";
        validationMessage.textContent = successMessage;
        validationMessage.style.color = "green"; 
        console.log(successMessage); 
    }

